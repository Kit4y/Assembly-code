#include <stdio.h>
#include <stdlib.h>

int main() {
    unsigned int data[] = {1,2,3,4,5,6,7,8,9,10,11,12,13};
    int odd_sum = 0; // ����
    int even_sum = 0; // ż��
    int ret = 0;
    int i;
    for (i=0; i < 13; i++) {
        if (data[i]%2 == 0) odd_sum += data[i];
        else even_sum += data[i];
    }
    if (odd_sum > even_sum) ret = odd_sum-even_sum;
    else ret = even_sum-odd_sum;

    printf("true: |%d-%d|=%d\n", odd_sum, even_sum, ret);

    odd_sum = 0; // ����
    even_sum = 0; // ż��
    ret = 0;
    _asm{
        mov eax, 0 // odd_sum
        mov ebx, 0 // even_sum

        mov esi, 0 // i
        lea edx, data
L0:
        cmp esi, 13
        je L1
        test [edx+esi*4], 1
        je L2
        adc ebx, [edx+esi*4]
        jmp L5
L2:
        adc eax, [edx+esi*4]
L5:
        adc esi, 1
        jmp L0

L1:
        mov odd_sum, eax
        mov even_sum, ebx
        cmp eax, ebx
        jle L3
        // eax > ebx
        sbb eax, ebx
        mov ret, eax
        jmp L4
L3:
        // ebx <= eax
        clc
        sbb ebx, eax
        mov ret, ebx
L4:
    }

    printf("|%d-%d|=%d\n", odd_sum, even_sum, ret);
    system("pause");
}