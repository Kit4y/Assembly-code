#include <stdio.h>
#include <stdlib.h>

int main() {
    char chs[5];
    unsigned short w1, w2;
    unsigned int dw;
    w1 = '21';
    w2 = '43';
    printf("正确结果:%d %d\n", w1, w2);
    dw = '4321';
    printf("%d\n\n", dw);

    scanf("%s", chs);

    _asm{
        lea eax, chs
        mov ebx, [eax]
        mov dw, ebx

        mov bx, [eax]
        mov w1, bx
        add eax, 2
        mov bx, [eax]
        mov w2, bx        
    }

    printf("字数据: %d %d\n双字数据: %d\n", w1, w2, dw);
    system("pause");
}