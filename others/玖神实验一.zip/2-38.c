#include <stdio.h>
#include <stdlib.h>

int main() {
	char chs[21] = {"12345678901234567890\0"};
	int pos_count = 0;
	int neg_count = 0;
	int ws[10] = {'21', '43', '65', '87', '09', '21', '43', '65', '87', '09'};
	int dws[5] = {'4321', '8765', '2109', '6543', '0987'};
	int i;

	printf("%s\n", chs);
	for (i = 0; i < 10; i++) {
		if (ws[i] > 0) pos_count++;
	}
	for (i = 0; i < 5; i++) {
		if (dws[i] < 0) neg_count++;
	}
	printf("true:\n%d\n%d\n", pos_count, neg_count);

	pos_count = 0;
	neg_count = 0;
	_asm {
		lea eax, chs
		mov ebx, 0
		mov edx, 0
L0:
		cmp ebx, 10
		jge L1
		mov cx, [eax]
		cmp cx, 0
		jle L2
		adc edx, 1
L2:
		adc ebx, 1
		adc eax, 2
		jmp L0
L1:
		mov pos_count, edx
	}
	printf("%d\n", pos_count);

	_asm {
		lea eax, chs
		mov ebx, 0
		mov edx, 0
L3:
		cmp ebx, 5
		jge L5
		mov ecx, [eax]
		cmp ecx, 0
		jge L4
		adc edx, 1
L4:
		adc ebx, 1
		adc eax, 4
		jmp L3
L5:
		mov neg_count, edx
	}
	
	printf("%d\n", neg_count);
	system("pause");
}