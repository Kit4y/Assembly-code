#include<stdio.h>

int main2_2() {
	char a[100];
	int b;
	scanf_s("%s", &a, 99);
	_asm {
		LEA EAX, [a]
		XOR ECX, ECX
		DEC ECX
		;
	INCREASE:
		INC ECX
			MOV DL, [EAX + ECX]
			CMP DL, 0
			JNE INCREASE
			;
		MOV b, ECX;
	}
	printf("%d", b);
	return 0;
}

