#include<stdio.h>

int main2_3() {
	char a[11] = { 10,1,2,3,4,5,6,7,8,-1,0 };
	int b, c;
	_asm {
		LEA EAX, [a]
		XOR ECX, ECX
		XOR EDX, EDX
		LOOOP:
			CMP [EAX], 0
			JE LOOPOVER

			MOV BL, [EAX]
			MOVZX EBX, BL
			ADD ECX, EBX

			MOV BL, [EAX]
			MOVSX EBX, BL
			ADD EDX, EBX

			INC EAX
			JMP LOOOP
		LOOPOVER:
		MOV b, ECX
		MOV c, EDX
	}
	printf("unsigned:%d signed:%d", b , c);
	return 0;
}