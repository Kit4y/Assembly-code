#include<stdio.h>

int main2_1() {
	int a, b, c, d;
	scanf_s("%d %d", &a, &b);
	_asm {
		MOV EAX, a

		CMP	EAX, b
		JG ABIGGER1
		MOV EAX, b
		ABIGGER1:
		MOV c, EAX
		;

		CMP	EAX, b
		JA ABIGGER2
		MOV EAX, b
		ABIGGER2 :
		MOV d, EAX
		;
	}
	printf("signed=%d unsigned=%u", c, d);
	return 0;
}